
public class Sales {
	
	
	public void salesOption() {
		
		System.out.println(" 1.Sales Party \n 2.Sales Order \n 3.Exit \n");
		
	}

}
